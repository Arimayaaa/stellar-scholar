# Stellar Scholar

Bu proje artik klasik bir `payment` demosu degil; bagisi testnet uzerinde gonderen ve ayni transaction icinde Soroban akilli kontratina kaydeden bir yapiya donusturuldu.

## Ne degisti?

- Mevcut bagis arayuzu korundu.
- Arka tarafa Soroban RPC ile calisan bir Node.js sunucusu eklendi.
- Rust ile yazilmis bir Soroban kontrati eklendi: [`contracts/stellar-scholar/src/lib.rs`](./contracts/stellar-scholar/src/lib.rs)
- Bagis odemesi ve `record_donation` kontrat cagrisi tek transaction icinde yapiliyor.
- Kontrat deploy edilmediyse sistem bunu UI'da acikca gosteriyor.

## Soroban kontrati ne yapiyor?

Kontrat su verileri tutar:

- Toplam bagis sayisi
- Toplam bagis tutari
- Her bagis icin `donation_id`
- Donor adresi
- Alici adresi
- Tutar (`stroops`)
- Bagis notu
- Zincir zamani

Fonksiyonlar:

- `record_donation(donor, destination, amount_stroops, memo)`
- `get_donation(donation_id)`
- `get_summary()`
- `list_recent(limit)`

## Testnet durumu

- Network: `Stellar Testnet`
- RPC: `https://soroban-testnet.stellar.org`
- Kontrat durumu: `Deploy edilmedi`
- Kontrat deploy adresi: `Henuz olusturulmadi`
- Deploy sonrasi `.env` icindeki `SOROBAN_CONTRACT_ID` alanina yazilacak deger: `C...`

Bu satiri bilerek bos biraktim; isteginize uygun olarak repoda deploy edilmis kontrat birakilmadi.

## Proje yapisi

```text
.
├── contracts/stellar-scholar/      # Soroban akilli kontrati
├── scripts/deploy-contract.js      # Testnet deploy scripti
├── server.js                       # Node/Express + Soroban RPC sunucusu
├── stellar projem/index.html       # Arayuz
├── stellar projem/index.js         # Tarayici tarafi mantik
├── .env.example
├── Cargo.toml
└── package.json
```

## Calistirma

### 1. JavaScript bagimliliklarini kur

```bash
pnpm install
```

### 2. Ortam dosyasini hazirla

```bash
cp .env.example .env
```

`.env` icinde su alanlari doldurun:

- `STELLAR_SECRET_KEY`
- `DONATION_DESTINATION`
- `SOROBAN_CONTRACT_ID`

Not:

- `STELLAR_SECRET_KEY` testnet hesabina ait olmali.
- Hesap fonlu degilse Friendbot ile fonlayin.
- `SOROBAN_CONTRACT_ID` bos ise arayuz acilir ama zincire kayit gondermez.

### 3. Uygulamayi baslat

```bash
pnpm start
```

Ardindan:

```text
http://localhost:3000
```

## Kontrati build etme

Rust ve Stellar CLI kuruluysa:

```bash
stellar contract build
```

Alternatif olarak workspace icinden:

```bash
cargo build --target wasm32v1-none --release
```

Beklenen WASM cikti dosyasi:

```text
target/wasm32v1-none/release/stellar_scholar.wasm
```

## Testnet deploy

Bu repo kontrati deploy etmez; sadece deploy etmeye hazir halde gelir.

Deploy etmek isterseniz:

```bash
pnpm deploy:contract
```

Script basarili olursa terminale sunlari yazar:

- `Wasm hash`
- `Contract ID`

Sonra:

1. `Contract ID` degerini kopyalayin.
2. `.env` icindeki `SOROBAN_CONTRACT_ID` alanina yapistirin.
3. Sunucuyu yeniden baslatin.

## Islem akisi

Kullanici "Bagisi Gonder" dediginde:

1. Sunucu XLM odeme operasyonunu hazirlar.
2. Ayni transaction icine `record_donation` Soroban cagrisi eklenir.
3. RPC `prepareTransaction` ile Soroban verisini tamamlar.
4. Transaction testnet'e gonderilir.
5. Basarili olursa hem odeme hem kontrat kaydi tek seferde kesinlesir.

Bu tasarim, odemenin gidip kontrat kaydinin yazilmamasi gibi tutarsizliklari azaltir.

## Kontrat testi

Rust test dosyasi:

- [`contracts/stellar-scholar/src/test.rs`](./contracts/stellar-scholar/src/test.rs)

Bu test, bagis kaydi yazma ve `get_summary` sonucunu kontrol eder.

## Onemli notlar

- Repodan hardcoded secret key kaldirildi.
- Kontrat ID artik kod icinde degil, `.env` ile veriliyor.
- Uygulama testnet odaklidir.
- README bilerek gercek bir contract ID icermiyor; cunku kontrat deploy edilmemis halde teslim edildi.

## Yararlanilan resmi kaynaklar

- Stellar Soroban storage örneği: https://developers.stellar.org/docs/build/smart-contracts/getting-started/storing-data
- JS SDK ile kontrat invoke: https://developers.stellar.org/docs/build/guides/transactions/invoke-contract-tx-sdk
- JS SDK ile transaction submit/poll: https://developers.stellar.org/docs/build/guides/transactions/submit-transaction-wait-js
- JS ile install/deploy akisi: https://developers.stellar.org/docs/build/guides/transactions/install-deploy-contract-with-code
